# Currently Amped — Parallel Inverter Dashboard

A FlowFuse Dashboard 2.0 (Node-RED, Venus OS) for monitoring **parallel Victron VE.Bus
inverter/charger systems** — per-unit load sharing, current-sharing balance, AC output
voltages, and live imbalance alerting, in the Currently Amped dark aesthetic.

Built on the original `parallel imbalance` flow and extended into a full dashboard.

![Inverter Load page](docs/images/inverter-load.png)

---

## What's in it

One importable flow adds/updates three pages on the **"My Dashboard"** base:

| Page | Path | Description |
|------|------|-------------|
| **Inverter Load %** | `/load` | Per-unit load bars, phase gauges, balance, voltages, alerts |
| **Parallel Balance** | `/pb` | Per-unit AC in/out tables with balance colour cells |
| **Load History** | `/page2` | 60-minute per-unit load line graphs (auto-ranging) |

### Inverter Load % page highlights
- **Per-unit load bars** as a percentage of each unit's configured maximum, grouped by phase.
- **Imbalance heat gradient** — green (lightest) → red (hardest); a **▲ hardest** flag per phase. Colour intensity scales with the real spread, so balanced phases stay calm.
- **Phase load gauge** (left), bars (centre), and a **per-unit readout list** (right: %, kW, voltage).
- **Current-sharing balance** per phase (lowest ÷ highest, spread ÷ average) on **Output and Input**.
- **Per-unit AC output voltage** with **loose-connection detection** — a unit whose voltage drifts from its phase-siblings is flagged (⚠ "check connection / retorque").
- **Imbalance alert banner** — fires on current-sharing, phase-voltage, or per-unit-voltage imbalance.
- **Automatic detection** of unit count, phase configuration, and per-unit rating; the graphs auto-range to the detected rating.

---

## Install (deploy)

1. In Node-RED: **menu → Import**.
2. Select `dist/parallel imbalance frank warwick 20 aug 2026 with currently amped dash.json`.
3. **Import → Deploy.**

The flow reuses the original node IDs, so Node-RED will offer to **replace** the existing
Parallel Balance nodes — this is intended and yields one unified dark dashboard.

**MQTT** is expected on `localhost:1883` (the GX/Venus OS broker). Topics subscribed:

| Topic | Purpose |
|-------|---------|
| `N/+/vebus/+/Devices/+/Ac/+/P` | Per-unit AC in/out power |
| `N/+/vebus/+/Ac/Out/+/V` | Phase AC output voltage |
| `N/+/vebus/+/Devices/+/Ac/+/V` | Per-unit AC output voltage (if published) |

Instance is auto-detected on the Inverter Load page; the original pages keep instance `276`.

---

## Configuration

All knobs are at the top of the **Build load % bars** function (edit in Node-RED, or in
`src/load_fn.js` and rebuild):

| Setting | Default | Purpose |
|---------|---------|---------|
| `RATED_W_PER_UNIT` | `0` (auto) | Per-unit rating; `0` auto-detects, or set e.g. `20000` to pin |
| `RATED_W_OVERRIDES` | `{}` | Per-device rating overrides for mixed banks |
| `DIRECTION_MODE` | `"both"` | `"out"`, `"in"`, or `"both"` |
| `BAR_COLOUR_MODE` | `"severity"` | `"severity"` heat, or `"phase"` solid colour |
| `SPREAD_FULL_RATIO` | `0.25` | Phase spread treated as "fully severe" |
| `BAL_WARN_PCT` / `BAL_CRIT_PCT` | `85` / `78` | Current-sharing alert thresholds |
| `VOLT_WARN_PCT` / `VOLT_CRIT_PCT` | `2.0` / `4.0` | Phase voltage-imbalance thresholds |
| `UNIT_V_WARN` / `UNIT_V_CRIT` | `1.5` / `3.0` V | Per-unit voltage-deviation (loose-connection) thresholds |
| `PHASE_COLOURS` | amber/green/blue | Per-phase badge/arc colours |

---

## Build from source

The deployable JSON is generated from the sources in `src/`:

```bash
node build.js
# writes dist/parallel imbalance frank warwick 20 aug 2026 with currently amped dash.json
```

`build.js` merges the original flow (`src/original-flow.json`, re-skinned dark) with the
Inverter Load page assembled from `src/load_fn.js`, `src/load_template.html`, and
`src/graph_fn.js`. No dependencies — plain Node.js.

---

## Repository layout

```
.
├── dist/            # deployable Node-RED flow (import this)
├── src/             # sources: functions, dashboard template, original flow
│   ├── load_fn.js
│   ├── load_template.html
│   ├── graph_fn.js
│   └── original-flow.json
├── docs/images/     # screenshots
├── build.js         # assembles dist/ from src/
├── CHANGELOG.md
└── README.md
```

---

## Notes

- **Per-unit voltage vs current sharing.** Paralleled units regulate to a common AC bus, so a
  high-resistance joint usually shows first as that unit **carrying less current** (the heat bars)
  and as heat at the lug; a per-unit **voltage** offset appears when the unit senses at its own
  terminals ahead of the bad joint. The two signals are complementary.
- **Auto-rating climbs with load** — until a bank runs near its rating, auto-detect may sit one
  class low. Set `RATED_W_PER_UNIT` to remove any doubt.

---

## Credits

Original `parallel imbalance` flow by Frank / Warwick. Dashboard extension and dark theme by
**Currently Amped** (Harare, Zimbabwe).
